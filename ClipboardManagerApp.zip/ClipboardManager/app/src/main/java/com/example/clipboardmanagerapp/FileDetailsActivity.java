package com.example.clipboardmanagerapp;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class FileDetailsActivity extends AppCompatActivity {

    private TextView fileNameView;
    private ListView clipboardListView;
    private ClipboardAdapter clipboardAdapter;
    private List<Clipboard> clipboardList;
    private String fileName;

    private static final String PREFS_NAME = "FilePrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_details);

        fileNameView = findViewById(R.id.fileNameView);
        clipboardListView = findViewById(R.id.clipboardListView);
        Button addClipboardButton = findViewById(R.id.addClipboardButton);

        fileName = getIntent().getStringExtra("fileName");
        fileNameView.setText(fileName);

        clipboardList = loadClipboards(fileName);

        clipboardAdapter = new ClipboardAdapter(this, clipboardList);
        clipboardListView.setAdapter(clipboardAdapter);

        addClipboardButton.setOnClickListener(view -> showAddClipboardDialog());
    }

    private void showAddClipboardDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Clipboard Details");

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_clipboard, null);
        EditText clipboardNameInput = dialogView.findViewById(R.id.clipboardNameInput);
        EditText clipboardContentInput = dialogView.findViewById(R.id.clipboardContentInput);

        builder.setView(dialogView);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String clipboardName = clipboardNameInput.getText().toString().trim();
            String clipboardContent = clipboardContentInput.getText().toString().trim();

            if (clipboardName.isEmpty()) {
                showErrorDialog("Clipboard name cannot be empty.");
                return;
            }

            clipboardList.add(new Clipboard(clipboardName, clipboardContent));
            saveClipboards(fileName);
            clipboardAdapter.notifyDataSetChanged();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void saveClipboards(String fileName) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();

        Set<String> clipboardSet = new HashSet<>();
        for (Clipboard clipboard : clipboardList) {
            clipboardSet.add(clipboard.getName() + ":" + clipboard.getContent());
        }

        editor.putStringSet(fileName, clipboardSet);
        editor.apply();
    }

    private List<Clipboard> loadClipboards(String fileName) {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> clipboardSet = prefs.getStringSet(fileName, new HashSet<>());

        List<Clipboard> clipboards = new ArrayList<>();
        for (String clipboardData : clipboardSet) {
            String[] parts = clipboardData.split(":", 2);
            String name = parts[0];
            String content = parts.length > 1 ? parts[1] : "";
            clipboards.add(new Clipboard(name, content));
        }
        return clipboards;
    }

    private class ClipboardAdapter extends ArrayAdapter<Clipboard> {
        public ClipboardAdapter(Context context, List<Clipboard> clipboards) {
            super(context, R.layout.clipboard_item, clipboards);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = LayoutInflater.from(getContext()).inflate(R.layout.clipboard_item, parent, false);
            }

            Clipboard clipboard = getItem(position);

            TextView clipboardNameView = convertView.findViewById(R.id.clipboardName);
            TextView clipboardContentView = convertView.findViewById(R.id.clipboardContent);
            Button copyClipboardButton = convertView.findViewById(R.id.copyClipboardButton);
            Button editClipboardButton = convertView.findViewById(R.id.editClipboardButton);
            Button deleteClipboardButton = convertView.findViewById(R.id.deleteClipboardButton);

            clipboardNameView.setText(clipboard.getName());
            clipboardContentView.setText(clipboard.getContent());

            copyClipboardButton.setOnClickListener(view -> {
                ClipboardManager clipboardManager = (ClipboardManager) getContext().getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("Clipboard Content", clipboard.getContent());
                clipboardManager.setPrimaryClip(clip);
                Toast.makeText(getContext(), "Copied to clipboard", Toast.LENGTH_SHORT).show();
            });

            editClipboardButton.setOnClickListener(view -> showEditClipboardDialog(position));
            deleteClipboardButton.setOnClickListener(view -> {
                clipboardList.remove(position);
                saveClipboards(fileName);
                notifyDataSetChanged();
            });

            return convertView;
        }
    }

    private void showEditClipboardDialog(int position) {
        Clipboard clipboard = clipboardList.get(position);

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Edit Clipboard");

        View dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_add_clipboard, null);
        EditText clipboardNameInput = dialogView.findViewById(R.id.clipboardNameInput);
        EditText clipboardContentInput = dialogView.findViewById(R.id.clipboardContentInput);

        clipboardNameInput.setText(clipboard.getName());
        clipboardContentInput.setText(clipboard.getContent());

        builder.setView(dialogView);

        builder.setPositiveButton("Save", (dialog, which) -> {
            clipboard.setName(clipboardNameInput.getText().toString().trim());
            clipboard.setContent(clipboardContentInput.getText().toString().trim());
            saveClipboards(fileName);
            clipboardAdapter.notifyDataSetChanged();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void showErrorDialog(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }
}