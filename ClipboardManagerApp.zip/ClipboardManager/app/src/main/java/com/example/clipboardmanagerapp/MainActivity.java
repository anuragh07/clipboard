package com.example.clipboardmanagerapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.SearchView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MainActivity extends AppCompatActivity {

    private SearchView searchView;
    private ListView fileListView;
    private ArrayAdapter<String> fileAdapter;
    private List<String> fileList;
    private List<String> displayedFiles;

    private static final String PREFS_NAME = "FilePrefs";
    private static final String FILE_LIST_KEY = "FileList";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        searchView = findViewById(R.id.searchView);
        fileListView = findViewById(R.id.fileListView);
        Button addFileButton = findViewById(R.id.addFileButton);


        fileList = loadFilesFromPreferences();
        displayedFiles = new ArrayList<>(fileList);


        fileAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, displayedFiles);
        fileListView.setAdapter(fileAdapter);


        addFileButton.setOnClickListener(view -> showAddFileDialog());


        fileListView.setOnItemClickListener((parent, view, position, id) -> {
            String fileName = displayedFiles.get(position);
            Intent intent = new Intent(MainActivity.this, FileDetailsActivity.class);
            intent.putExtra("fileName", fileName);
            startActivity(intent);
        });


        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                filterFiles(query);
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                filterFiles(newText);
                return false;
            }
        });
    }

    private void showAddFileDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter File Name");

        final EditText input = new EditText(this);
        builder.setView(input);

        builder.setPositiveButton("Create", (dialog, which) -> {
            String fileName = input.getText().toString().trim();
            if (fileName.isEmpty()) {
                // Notify the user if the file name is empty
                showErrorDialog("File name cannot be empty.");
                return;
            }
            if (fileList.contains(fileName)) {
                // Notify the user if the file name already exists
                showErrorDialog("File with this name already exists.");
                return;
            }
            addNewFile(fileName);
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void showErrorDialog(String message) {
        new AlertDialog.Builder(this)
                .setTitle("Error")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .show();
    }

    private void addNewFile(String fileName) {
        fileList.add(fileName);
        saveFilesToPreferences();

        // Update displayed files and refresh the adapter
        filterFiles(searchView.getQuery().toString());
    }

    private void filterFiles(String query) {
        displayedFiles.clear();
        if (query.isEmpty()) {
            displayedFiles.addAll(fileList);
        } else {
            for (String file : fileList) {
                if (file.toLowerCase().contains(query.toLowerCase())) {
                    displayedFiles.add(file);
                }
            }
        }
        fileAdapter.notifyDataSetChanged();
    }

    private void saveFilesToPreferences() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        Set<String> fileSet = new HashSet<>(fileList);
        editor.putStringSet(FILE_LIST_KEY, fileSet);
        editor.apply();
    }

    private List<String> loadFilesFromPreferences() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        Set<String> fileSet = prefs.getStringSet(FILE_LIST_KEY, new HashSet<>());
        return new ArrayList<>(fileSet);
    }
}